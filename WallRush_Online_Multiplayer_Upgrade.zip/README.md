# WallRush Online — Unity Android starter

This package adds **random online matchmaking and quick-message emotes** using Photon PUN 2.

## Important before you start
This is source code for a prototype, not a finished published game. Photon needs an App ID and the Photon PUN 2 SDK. You must create/configure the Photon application in your own account. Online play cannot work until that setup is complete.

## Setup
1. Create a Unity 2D project.
2. Import **Photon PUN 2** from the Unity Asset Store / Photon documentation.
3. In Photon Dashboard, create a Photon application of type **PUN** and copy its App ID.
4. In Unity, open **Window > Photon Unity Networking > PUN Wizard** (menu wording can vary by SDK version), paste the App ID, and apply it.
5. Copy `Assets/Scripts/WallRushOnlineGame.cs` into the Unity project's `Assets/Scripts`.
6. Create an empty GameObject named `WallRushOnlineGame` and attach this script.
7. Ensure your scene is saved and included in Build Settings.
8. Test with two separate game instances/devices connected to the internet.
9. For Android builds, install Android Build Support (SDK/NDK/OpenJDK) through Unity Hub, switch platform to Android, choose Portrait orientation, then Build and Run.

## Online features in this prototype
- Searches for a random public room with an available player; creates a room if none is available.
- Two players per room.
- Shared turn-based movement and wall placement via Photon RPCs.
- Quick messages/emotes: `Rematch?`, `Hi!`, `Yes`, `No`, `Good game!`, `😂`, `🤔`, `🤝`, `😡`, `👍`, `❤️`, `👏`.
- Detects when the other player leaves.

## Limitations / known prototype status
- This is not production-ready matchmaking; no server-authoritative validation, accounts, reports, moderation, anti-cheat, reconnect/resume, or ranking.
- Quick messages are intentionally fixed buttons, not free-text chat.
- Photon free-tier limits and current product terms apply.
- The current wall placement route-check is a prototype implementation; test extensively before release.
- Online actions are synchronized through Photon RPCs. Do not use this as a commercial release without adding robust validation and testing.
- Depending on the installed PUN version and Unity version, the UI text/font API may require minor compatibility edits.
